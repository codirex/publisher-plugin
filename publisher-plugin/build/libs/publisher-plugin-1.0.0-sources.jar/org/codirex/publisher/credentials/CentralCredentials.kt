package org.codirex.publisher.credentials

import java.util.Base64

data class CentralCredentials(
    val username: String,
    val password: String
) {
    val basicAuthHeader: String
        get() = "Basic " + Base64.getEncoder().encodeToString("$username:$password".toByteArray())
}
