package org.codirex.publisher.task

import org.codirex.publisher.credentials.CredentialResolver
import org.codirex.publisher.dsl.PublishTarget
import org.codirex.publisher.dsl.PublisherExtension
import org.codirex.publisher.targets.central.BundleGenerator
import org.codirex.publisher.targets.central.CentralDeployManager
import org.gradle.api.DefaultTask
import org.gradle.api.tasks.Internal
import org.gradle.api.tasks.TaskAction
import java.io.File

/**
 * Bundles the local staging repo (populated by
 * `publishReleasePublicationToCentralStagingRepository`) into `bundle.zip`
 * and uploads it through the Central Portal API, polling until it's published.
 */
open class PublishToCentralTask : DefaultTask() {

    @get:Internal
    lateinit var publisherExtension: PublisherExtension

    @get:Internal
    lateinit var stagingDir: File

    init {
        group = "publishing"
        description = "Bundles and uploads this module's release artifacts to Maven Central via the Central Portal."
    }

    @TaskAction
    fun publish() {
        if (PublishTarget.MAVEN_CENTRAL !in publisherExtension.targets.enabled) {
            logger.lifecycle("Maven Central not enabled for ${project.path}, skipping.")
            return
        }
        val credentials = CredentialResolver(project).requireCentral()
        val bundle = BundleGenerator(project).createBundle(stagingDir)
        CentralDeployManager(credentials).deploy(bundle)
    }
}
