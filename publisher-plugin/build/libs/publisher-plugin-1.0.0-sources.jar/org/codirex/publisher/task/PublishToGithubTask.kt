package org.codirex.publisher.task

import org.codirex.publisher.dsl.PublishTarget
import org.codirex.publisher.dsl.PublisherExtension
import org.gradle.api.DefaultTask
import org.gradle.api.tasks.Internal
import org.gradle.api.tasks.TaskAction

/**
 * Lifecycle task for GitHub Packages. The actual upload is done by the
 * maven-publish-generated `publishReleasePublicationToGithubPackagesRepository`
 * task, which this depends on (wired in PublisherPlugin) when the target is enabled.
 */
open class PublishToGithubTask : DefaultTask() {

    @get:Internal
    lateinit var publisherExtension: PublisherExtension

    init {
        group = "publishing"
        description = "Publishes this module's release artifacts to GitHub Packages."
    }

    @TaskAction
    fun report() {
        if (PublishTarget.GITHUB_PACKAGES !in publisherExtension.targets.enabled) {
            logger.lifecycle("GitHub Packages not enabled for ${project.path}, skipping.")
        } else {
            logger.lifecycle("Published ${publisherExtension.artifactId} to GitHub Packages.")
        }
    }
}
