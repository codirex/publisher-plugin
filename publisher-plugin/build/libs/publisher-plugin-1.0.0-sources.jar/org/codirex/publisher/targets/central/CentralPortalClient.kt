package org.codirex.publisher.targets.central

import org.codirex.publisher.credentials.CentralCredentials
import java.io.File
import java.net.URI
import java.net.http.HttpClient
import java.net.http.HttpRequest
import java.net.http.HttpResponse
import java.time.Duration

enum class DeploymentState { PENDING, VALIDATING, VALIDATED, PUBLISHING, PUBLISHED, FAILED, UNKNOWN }

/**
 * Thin client for the Sonatype Central Publisher Portal API
 * (https://central.sonatype.com/api-doc). Endpoint paths here reflect the
 * documented API as of this writing; Sonatype has changed this API before,
 * so double-check against their current docs if uploads start failing.
 */
class CentralPortalClient(
    private val credentials: CentralCredentials,
    private val httpClient: HttpClient = HttpClient.newBuilder()
        .connectTimeout(Duration.ofSeconds(10))
        .build()
) {
    private val baseUrl = "https://central.sonatype.com/api/v1/publisher"

    fun uploadBundle(bundle: File, publishingType: String = "AUTOMATIC"): String {
        val boundary = "----CodirexPublisher${System.currentTimeMillis()}"
        val body = multipartBody(bundle, boundary)

        val request = HttpRequest.newBuilder()
            .uri(URI.create("$baseUrl/upload?publishingType=$publishingType"))
            .header("Authorization", credentials.basicAuthHeader)
            .header("Content-Type", "multipart/form-data; boundary=$boundary")
            .timeout(Duration.ofMinutes(5))
            .POST(HttpRequest.BodyPublishers.ofByteArray(body))
            .build()

        val response = httpClient.send(request, HttpResponse.BodyHandlers.ofString())
        check(response.statusCode() in 200..299) {
            "Central Portal upload failed (${response.statusCode()}): ${response.body()}"
        }
        return response.body().trim() // API returns the deployment id as plain text
    }

    fun deploymentStatus(deploymentId: String): DeploymentState {
        val request = HttpRequest.newBuilder()
            .uri(URI.create("$baseUrl/status?id=$deploymentId"))
            .header("Authorization", credentials.basicAuthHeader)
            .POST(HttpRequest.BodyPublishers.noBody())
            .build()

        val response = httpClient.send(request, HttpResponse.BodyHandlers.ofString())
        if (response.statusCode() !in 200..299) return DeploymentState.UNKNOWN

        val state = Regex("\"deploymentState\"\\s*:\\s*\"(\\w+)\"")
            .find(response.body())?.groupValues?.get(1)
        return runCatching { DeploymentState.valueOf(state ?: "UNKNOWN") }
            .getOrDefault(DeploymentState.UNKNOWN)
    }

    private fun multipartBody(file: File, boundary: String): ByteArray {
        val header = (
            "--$boundary\r\n" +
                "Content-Disposition: form-data; name=\"bundle\"; filename=\"${file.name}\"\r\n" +
                "Content-Type: application/zip\r\n\r\n"
        ).toByteArray()
        val footer = "\r\n--$boundary--\r\n".toByteArray()
        return header + file.readBytes() + footer
    }
}
