package org.codirex.publisher.targets.central

import org.codirex.publisher.credentials.CentralCredentials
import org.gradle.api.GradleException
import org.gradle.api.logging.Logging
import java.io.File

/** Orchestrates bundle upload + status polling against the Central Portal. */
class CentralDeployManager(credentials: CentralCredentials) {

    private val logger = Logging.getLogger(CentralDeployManager::class.java)
    private val client = CentralPortalClient(credentials)

    fun deploy(bundle: File, pollIntervalMs: Long = 5000, maxAttempts: Int = 60) {
        val deploymentId = client.uploadBundle(bundle)
        logger.lifecycle("Uploaded to Central Portal, deployment id: $deploymentId")

        repeat(maxAttempts) { attempt ->
            when (val state = client.deploymentStatus(deploymentId)) {
                DeploymentState.PUBLISHED -> {
                    logger.lifecycle("Central Portal deployment $deploymentId published.")
                    return
                }
                DeploymentState.FAILED -> throw GradleException(
                    "Central Portal deployment $deploymentId failed. Check " +
                        "https://central.sonatype.com/publishing/deployments"
                )
                else -> {
                    logger.lifecycle(
                        "Central Portal deployment $deploymentId: $state " +
                            "(attempt ${attempt + 1}/$maxAttempts)"
                    )
                    Thread.sleep(pollIntervalMs)
                }
            }
        }
        logger.warn(
            "Timed out waiting for deployment $deploymentId to finish. It may still complete; check " +
                "https://central.sonatype.com/publishing/deployments"
        )
    }
}
