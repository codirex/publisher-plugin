package org.codirex.publisher.dsl

import org.codirex.publisher.metadata.GithubRepoRef
import org.codirex.publisher.metadata.GithubSyncEngine
import org.codirex.publisher.metadata.RepoMetadata
import org.gradle.api.Project

/**
 * `metadata { syncFrom(github("codirex/axiom")); license = Licenses.APACHE_2_0 }`
 *
 * [syncFrom] just records which GitHub repo to pull from; the actual network
 * call happens lazily the first time [resolve] is called (during POM
 * generation), so plain `./gradlew tasks` or offline builds that never touch
 * publishing never hit the network.
 */
class MetadataDsl(private val project: Project) {

    var license: License = Licenses.APACHE_2_0
    var description: String = ""
    var projectUrl: String = ""
    var scmUrl: String = ""
    var developers: List<Pair<String, String>> = emptyList()

    var repoRef: GithubRepoRef? = null
        private set

    private var synced: RepoMetadata? = null

    fun syncFrom(repo: GithubRepoRef) {
        repoRef = repo
    }

    /** Fetches (and caches) metadata from GitHub, filling in any blanks the user didn't set explicitly. */
    fun resolve(): RepoMetadata? {
        val ref = repoRef ?: return null
        synced?.let { return it }

        val fetched = GithubSyncEngine().fetch(ref)
        synced = fetched
        if (description.isBlank()) description = fetched.description.orEmpty()
        if (projectUrl.isBlank()) projectUrl = fetched.htmlUrl.orEmpty()
        if (scmUrl.isBlank()) scmUrl = fetched.cloneUrl.orEmpty()
        return fetched
    }
}

fun github(fullName: String): GithubRepoRef {
    val parts = fullName.split("/")
    require(parts.size == 2 && parts.all { it.isNotBlank() }) {
        "Expected \"owner/repo\", got \"$fullName\""
    }
    return GithubRepoRef(owner = parts[0], repo = parts[1])
}
