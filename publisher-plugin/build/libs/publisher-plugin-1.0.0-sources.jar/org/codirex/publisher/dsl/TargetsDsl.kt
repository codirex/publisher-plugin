package org.codirex.publisher.dsl

enum class PublishTarget { MAVEN_CENTRAL, GITHUB_PACKAGES }

/** `targets { mavenCentral(); githubPackages() }` */
class TargetsDsl {
    private val _enabled = linkedSetOf<PublishTarget>()
    val enabled: Set<PublishTarget> get() = _enabled

    fun mavenCentral() {
        _enabled += PublishTarget.MAVEN_CENTRAL
    }

    fun githubPackages() {
        _enabled += PublishTarget.GITHUB_PACKAGES
    }
}
