package org.codirex.publisher.dsl

import org.codirex.publisher.credentials.CredentialsDsl
import org.gradle.api.Project
import javax.inject.Inject

/**
 * The `publisher { ... }` block. One of these is created per module the
 * plugin is applied to (see [org.codirex.publisher.PublisherPlugin]).
 */
open class PublisherExtension @Inject constructor(private val project: Project) {

    internal var identityRef: IdentityDsl? = null
        private set

    val groupId: String get() = identityRef?.groupId.orEmpty()
    val artifactId: String get() = identityRef?.artifactId.orEmpty()
    val version: String get() = identityRef?.version.orEmpty()

    val metadata: MetadataDsl = MetadataDsl(project)
    val components: ComponentsDsl = ComponentsDsl()
    val credentials: CredentialsDsl = CredentialsDsl()
    val signing: SigningDsl = SigningDsl()
    val targets: TargetsDsl = TargetsDsl()

    fun identity(groupId: String, artifactId: String, version: String) {
        identityRef = IdentityDsl(groupId, artifactId, version)
    }

    fun metadata(action: MetadataDsl.() -> Unit) = metadata.apply(action)

    fun targets(action: TargetsDsl.() -> Unit) = targets.apply(action)

    /** Whether enough has been configured to bother wiring up maven-publish/signing/tasks at all. */
    fun isConfigured(): Boolean = identityRef != null
}
