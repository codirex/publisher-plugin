package org.codirex.publisher.engine

import com.android.build.gradle.LibraryExtension
import org.gradle.api.Project
import org.gradle.api.plugins.JavaPluginExtension

enum class ComponentType { ANDROID_LIBRARY, JAVA_LIBRARY, UNKNOWN }

/**
 * Figures out whether a module is an Android library or a plain JVM library
 * and makes sure the corresponding publishable component (with sources +
 * javadoc jars) is registered before maven-publish looks for it.
 */
class ComponentDetector(private val project: Project) {

    fun detect(): ComponentType = when {
        project.plugins.hasPlugin("com.android.library") -> ComponentType.ANDROID_LIBRARY
        project.plugins.hasPlugin("java-library") || project.plugins.hasPlugin("java") ->
            ComponentType.JAVA_LIBRARY
        else -> ComponentType.UNKNOWN
    }

    fun prepare(type: ComponentType) {
        when (type) {
            ComponentType.ANDROID_LIBRARY -> prepareAndroidLibrary()
            ComponentType.JAVA_LIBRARY -> prepareJavaLibrary()
            ComponentType.UNKNOWN -> throw IllegalStateException(
                "Publisher plugin could not detect a publishable component on '${project.path}'. " +
                    "Apply the 'com.android.library' or 'java-library' plugin before 'org.codirex.publisher'."
            )
        }
    }

    private fun prepareAndroidLibrary() {
        val android = project.extensions.getByType(LibraryExtension::class.java)
        android.publishing.singleVariant("release") {
            withSourcesJar()
            withJavadocJar()
        }
    }

    private fun prepareJavaLibrary() {
        project.extensions.getByType(JavaPluginExtension::class.java).apply {
            withSourcesJar()
            withJavadocJar()
        }
    }
}
