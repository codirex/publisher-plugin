package org.codirex.publisher.engine

import org.codirex.publisher.dsl.PublishTarget
import org.codirex.publisher.dsl.PublisherExtension
import org.codirex.publisher.metadata.PomGenerator
import org.codirex.publisher.targets.github.GithubPackagesClient
import org.gradle.api.Project
import org.gradle.api.publish.PublishingExtension
import org.gradle.api.publish.maven.MavenPublication

/**
 * Applies `maven-publish`, creates a single "release" [MavenPublication] for
 * whichever component [ComponentDetector] finds, and registers a repository
 * for each enabled [PublishTarget]:
 *  - GITHUB_PACKAGES -> pushes straight to https://maven.pkg.github.com/<owner>/<repo>
 *  - MAVEN_CENTRAL    -> writes to a local staging dir; [org.codirex.publisher.task.PublishToCentralTask]
 *                        bundles and uploads it via the Central Portal API afterwards.
 */
class MavenPublishOrchestrator(
    private val project: Project,
    private val extension: PublisherExtension
) {

    fun configure() {
        project.pluginManager.apply("maven-publish")

        val detector = ComponentDetector(project)
        val componentType = detector.detect()
        detector.prepare(componentType)

        val componentName = when (componentType) {
            ComponentType.ANDROID_LIBRARY -> "release"
            ComponentType.JAVA_LIBRARY -> "java"
            ComponentType.UNKNOWN -> return // detector.prepare() already threw
        }

        project.extensions.configure(PublishingExtension::class.java) { publishing ->
            publishing.publications.create("release", MavenPublication::class.java) { publication ->
                publication.from(project.components.getByName(componentName))
                publication.groupId = extension.groupId
                publication.artifactId = extension.artifactId
                publication.version = extension.version
                PomGenerator(extension.metadata, extension.artifactId).apply(publication.pom)
            }

            if (PublishTarget.MAVEN_CENTRAL in extension.targets.enabled) {
                publishing.repositories.maven { repo ->
                    repo.name = "CentralStaging"
                    repo.url = project.uri(project.layout.buildDirectory.dir("publisher/central-staging").get())
                }
            }

            if (PublishTarget.GITHUB_PACKAGES in extension.targets.enabled) {
                val repoRef = requireNotNull(extension.metadata.repoRef) {
                    "metadata { syncFrom(github(\"owner/repo\")) } is required to publish " +
                        "'${project.path}' to GitHub Packages."
                }
                GithubPackagesClient(project, repoRef.fullName).register()
            }
        }
    }
}
