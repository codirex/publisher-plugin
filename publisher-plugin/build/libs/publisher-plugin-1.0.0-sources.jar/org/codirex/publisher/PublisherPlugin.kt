package org.codirex.publisher

import org.codirex.publisher.dsl.EcosystemExtension
import org.codirex.publisher.dsl.PublishTarget
import org.codirex.publisher.dsl.PublisherExtension
import org.codirex.publisher.engine.MavenPublishOrchestrator
import org.codirex.publisher.engine.SigningConfigurator
import org.codirex.publisher.task.CheckPublisherConfigTask
import org.codirex.publisher.task.PublishAllTask
import org.codirex.publisher.task.PublishToCentralTask
import org.codirex.publisher.task.PublishToGithubTask
import org.gradle.api.Plugin
import org.gradle.api.Project

/**
 * Entry point for the `org.codirex.publisher` plugin.
 *
 * Applied to a single module, it registers the [PublisherExtension]
 * (`publisher { ... }`) and wires up maven-publish, signing, and the
 * publish-target tasks once that extension is configured.
 *
 * Applied to a multi-module root, it additionally registers the
 * [EcosystemExtension] (`publisherEcosystem { ... }`), which fans shared
 * defaults out to every subproject via `autoPublishModules { }`.
 */
class PublisherPlugin : Plugin<Project> {

    override fun apply(project: Project) {
        val publisherExtension = project.extensions.create(
            "publisher",
            PublisherExtension::class.java,
            project
        )

        if (project == project.rootProject) {
            project.extensions.create(
                "publisherEcosystem",
                EcosystemExtension::class.java,
                project
            )
        }

        project.afterEvaluate {
            if (publisherExtension.isConfigured()) {
                configureModule(project, publisherExtension)
            }
        }
    }

    private fun configureModule(project: Project, extension: PublisherExtension) {
        MavenPublishOrchestrator(project, extension).configure()
        SigningConfigurator(project, extension).configure()

        project.tasks.register("checkPublisherConfig", CheckPublisherConfigTask::class.java) { task ->
            task.publisherExtension = extension
        }

        val publishToGithub = project.tasks.register(
            "publishToGithubPackages",
            PublishToGithubTask::class.java
        ) { task ->
            task.publisherExtension = extension
            // Only depend on the maven-publish-generated task when the
            // GitHub repository was actually registered (see
            // MavenPublishOrchestrator) - otherwise the task doesn't exist
            // and Gradle fails resolving the task graph.
            if (PublishTarget.GITHUB_PACKAGES in extension.targets.enabled) {
                task.dependsOn("publishReleasePublicationToGithubPackagesRepository")
            }
        }

        val publishToCentral = project.tasks.register(
            "publishToMavenCentral",
            PublishToCentralTask::class.java
        ) { task ->
            task.publisherExtension = extension
            task.stagingDir = project.layout.buildDirectory.dir("publisher/central-staging").get().asFile
            if (PublishTarget.MAVEN_CENTRAL in extension.targets.enabled) {
                task.dependsOn("publishReleasePublicationToCentralStagingRepository")
            }
        }

        project.tasks.register("publishAll", PublishAllTask::class.java) { task ->
            task.dependsOn(publishToGithub, publishToCentral)
        }
    }
}
